public class przygotujDanie implements Komenda {
    private Zamowienie order;

    public przygotujDanie(Zamowienie order) {
        this.order = order;
    }

    @Override
    public void execute() {
        if (order.getStatus().equals("Przyjęte")) {
            System.out.println("Przygotowywanie posiłków dla zamówienia: " + order.getItems());
            order.setStatus("Przygotowane");
        } else {
            System.out.println("Zamówienie nie jest gotowe do przygotowania.");
        }
    }
}