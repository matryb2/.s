public interface Komenda {
    void execute();
}