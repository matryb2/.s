public class dostarczDanie implements Komenda {
    private Zamowienie order;

    public dostarczDanie(Zamowienie order) {
        this.order = order;
    }

    @Override
    public void execute() {
        if (order.getStatus().equals("Przygotowane")) {
            System.out.println("Dostarczanie zamówienia: " + order.getItems());
            order.setStatus("Dostarczone");
        } else {
            System.out.println("Zamówienie nie jest gotowe do dostarczenia.");
        }
    }
}