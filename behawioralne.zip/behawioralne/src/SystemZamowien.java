import java.util.List;
import java.util.Scanner;

public class SystemZamowien {
    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);
        System.out.println("Podaj dwie potrawy: ");
        System.out.println("Potrawa 1");
        String a = scan.nextLine();
        System.out.println("Potrawa 2");
        String b = scan.nextLine();


        Zamowienie order = new Zamowienie(List.of(a,b));

        zakolejkowaneKomendy c = new zakolejkowaneKomendy();

        c.dodajKomende(new odbierzZamowienie(order));
        c.dodajKomende(new przygotujDanie(order));
        c.dodajKomende(new dostarczDanie(order));

        c.wykonajKomende();
    }
}