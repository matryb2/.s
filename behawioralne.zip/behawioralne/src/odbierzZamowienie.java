public class odbierzZamowienie implements Komenda {
    private Zamowienie order;

    public odbierzZamowienie(Zamowienie order) {
        this.order = order;
    }

    @Override
    public void execute() {
        System.out.println("Zamówienie przyjęte: " + order.getItems());
        order.setStatus("Przyjęte");
    }
}

