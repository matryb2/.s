import java.util.List;

public class Zamowienie {
    private List<String> items;
    private String status;

    public Zamowienie(List<String> items) {
        this.items = items;
        this.status = "Nowe";
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getStatus() {
        return status;
    }

    public List<String> getItems() {
        return items;
    }
}