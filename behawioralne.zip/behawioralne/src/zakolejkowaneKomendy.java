import java.util.LinkedList;
import java.util.Queue;

public class zakolejkowaneKomendy {
    private Queue<Komenda> commands = new LinkedList<>();

    public void dodajKomende(Komenda command) {
        commands.add(command);
    }

    public void wykonajKomende() {
        while (!commands.isEmpty()) {
            Komenda command = commands.poll();
            command.execute();
        }
    }
}