import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        String email, haslo, login, numer;
        int token, liczba;

        Scanner scan = new Scanner(System.in);
        Scanner scan1 = new Scanner(System.in);
        LoginService loginService = new LoginService();

        System.out.println("Wybierz operacje: ");
        System.out.println("1 - Logowanie za pomoca loginu i hasla");
        System.out.println("2 - Logowanie za pomoca emaila i hasla");
        System.out.println("3 - Logowanie za pomoca loginu i tokenu");
        System.out.println("4 - Lgoowanie za pomoca numeru telefonu i hasla");
        liczba = scan1.nextInt();

        switch(liczba) {
            case 1:
                System.out.println("Podaj login: ");
                login = scan.nextLine();

                System.out.println("Podaj haslo: ");
                haslo = scan.nextLine();

                loginService.login(login, haslo);
            case 2:
                System.out.println("Podaj email: ");
                email = scan.nextLine();
                System.out.println("Podaj haslo: ");
                haslo = scan.nextLine();

                loginService.login("", email, haslo);
            case 3:
                System.out.println("Podaj login: ");
                login = scan.nextLine();
                System.out.println("Podaj token: ");
                token = scan1.nextInt();

                loginService.login(login, token);
            case 4:
                System.out.println("Podaj numer telefonu: ");
                numer = scan.nextLine();
                System.out.println("Podaj haslo: ");
                haslo = scan.nextLine();

                loginService.login(numer, haslo, 1);
            default:
                System.out.println("Wpisales zla zmienna!");
        }






        User admin = new Admin();
        User programmer = new Programmer();
        User tester = new Tester();
        User manager = new Manager();

        System.out.println("");
        System.out.println("Admin: " + admin.getAccessLevel());
        System.out.println("Programmer: " + programmer.getAccessLevel());
        System.out.println("Tester: " + tester.getAccessLevel());
        System.out.println("Manager: " + manager.getAccessLevel());
    }
}