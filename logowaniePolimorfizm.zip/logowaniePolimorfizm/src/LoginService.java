import java.util.HashMap;
import java.util.Map;

public class LoginService {
    private Map<String, String> dane;
    private Map<String, Integer> tokeny;
    private Map<String, String> telefony;

    public LoginService() {
        dane = new HashMap<>();
        tokeny = new HashMap<>();
        telefony = new HashMap<>();

        dane.put("user123", "password123");
        dane.put("user456", "password456");
        tokeny.put("user123", 123456);
        tokeny.put("user456", 654321);
        telefony.put("123456789", "user123");
        telefony.put("987654321", "user456");
    }

    public void login(String username, String password) {
        if (dane.containsKey(username) && dane.get(username).equals(password)) {
            System.out.println("Logowanie udane za pomocą loginu i hasła");
        } else {
            System.out.println("Logowanie nieudane za pomocą loginu i hasła");
        }
    }

    public void login(String login, String email, String password) {
        if (dane.containsKey(login) && dane.get(login).equals(password)) {
            System.out.println("Logowanie udane za pomocą e-maila i hasła");
        } else {
            System.out.println("Logowanie nieudane za pomocą e-maila i hasła");
        }
    }

    public void login(String username, int token) {
        if (tokeny.containsKey(username) && tokeny.get(username).equals(token)) {
            System.out.println("Logowanie udane za pomocą loginu i tokenu");
        } else {
            System.out.println("Logowanie nieudane za pomocą loginu i tokenu");
        }
    }

    public void login(String phoneNumber, String password, int cokolwiek) {
        String username = null;
        for (Map.Entry<String, String> entry : telefony.entrySet()) {
            if (entry.getValue().equals(phoneNumber)) {
                username = entry.getKey();
                break;
            }
        }

        if (username != null && dane.get(username).equals(password)) {
            System.out.println("Logowanie udane za pomocą numeru telefonu i hasła");
        } else {
            System.out.println("Logowanie nieudane za pomocą numeru telefonu i hasła");
        }
    }
}