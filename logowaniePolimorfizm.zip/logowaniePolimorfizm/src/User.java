abstract class User {
    public abstract String getAccessLevel();
}

class Admin extends User {
    @Override
    public String getAccessLevel() {
        return "Pełne uprawnienia";
    }
}

class Programmer extends User {
    @Override
    public String getAccessLevel() {
        return "Dostęp do kodu";
    }
}

class Tester extends User {
    @Override
    public String getAccessLevel() {
        return "Dostęp do środowiska testowego";
    }
}

class Manager extends User {
    @Override
    public String getAccessLevel() {
        return "Dostęp do raportów";
    }
}